﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace RGR.Taras
{
    public partial class Form1 : Form
    {
        int[,] field;
        int[,]? currentFigure;
        int figureX = 3, figureY = 0;
        System.Windows.Forms.Timer gameTimer = new System.Windows.Forms.Timer();
        Random rand = new Random();
        int score = 0;
        int blockSize = 30; // размер одного квадрата

        public Form1()
        {
            InitializeComponent();

            this.DoubleBuffered = true;
            this.Width = 320;
            this.Height = 520;
            this.Text = "Тетрис от Тараса :)";

            InitField();

            gameTimer.Interval = 500;
            gameTimer.Tick += GameTick;
            gameTimer.Start();

            SpawnFigure();

            this.Paint += new PaintEventHandler(Draw);
            this.KeyDown += new KeyEventHandler(OnKeyDown);
            this.Resize += (s, e) =>
            {
                InitField();
                Invalidate();
            };
        }

        void InitField()
        {
            int w = this.ClientSize.Width / blockSize;
            int h = this.ClientSize.Height / blockSize;
            field = new int[w, h];
        }

        int FieldWidth => this.ClientSize.Width / blockSize;
        int FieldHeight => this.ClientSize.Height / blockSize;

        void SpawnFigure()
        {
            var figures = new List<int[,]> {
                new int[,] { {1,1,1,1} },
                new int[,] { {1,1},{1,1} },
                new int[,] { {0,1,0},{1,1,1} },
                new int[,] { {1,0,0},{1,1,1} },
                new int[,] { {0,0,1},{1,1,1} },
                new int[,] { {0,1,1},{1,1,0} },
                new int[,] { {1,1,0},{0,1,1} }
            };

            currentFigure = figures[rand.Next(figures.Count)];
            figureX = FieldWidth / 2 - currentFigure.GetLength(0) / 2;
            figureY = 0;

            if (CheckCollision())
            {
                gameTimer.Stop();
                MessageBox.Show($"Игра окончена! Ваш счёт: {score}", "Game Over");
                Application.Exit();
            }
        }

        void GameTick(object? sender, EventArgs e)
        {
            figureY++;

            if (CheckCollision())
            {
                figureY--;
                PlaceFigure();
                ClearLines();
                SpawnFigure();
            }

            Invalidate();
        }

        void Draw(object? sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            for (int x = 0; x < FieldWidth; x++)
                for (int y = 0; y < FieldHeight; y++)
                    if (field[x, y] == 1)
                        g.FillRectangle(Brushes.Blue, x * blockSize, y * blockSize, blockSize, blockSize);

            if (currentFigure != null)
            {
                for (int x = 0; x < currentFigure.GetLength(0); x++)
                    for (int y = 0; y < currentFigure.GetLength(1); y++)
                        if (currentFigure[x, y] == 1)
                            g.FillRectangle(Brushes.Red, (figureX + x) * blockSize, (figureY + y) * blockSize, blockSize, blockSize);
            }

            g.DrawString($"Очки: {score}", new Font("Arial", 12), Brushes.Black, this.ClientSize.Width - 100, 10);
        }

        void OnKeyDown(object? sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                figureX--;
                if (CheckCollision()) figureX++;
            }
            else if (e.KeyCode == Keys.Right)
            {
                figureX++;
                if (CheckCollision()) figureX--;
            }
            else if (e.KeyCode == Keys.Down)
            {
                figureY++;
                if (CheckCollision())
                {
                    figureY--;
                    PlaceFigure();
                    ClearLines();
                    SpawnFigure();
                }
            }

            Invalidate();
        }

        bool CheckCollision()
        {
            if (currentFigure == null) return false;

            for (int x = 0; x < currentFigure.GetLength(0); x++)
            {
                for (int y = 0; y < currentFigure.GetLength(1); y++)
                {
                    if (currentFigure[x, y] == 1)
                    {
                        int newX = figureX + x;
                        int newY = figureY + y;

                        if (newX < 0 || newX >= FieldWidth || newY >= FieldHeight)
                            return true;

                        if (newY >= 0 && field[newX, newY] == 1)
                            return true;
                    }
                }
            }
            return false;
        }

        void PlaceFigure()
        {
            if (currentFigure == null) return;

            for (int x = 0; x < currentFigure.GetLength(0); x++)
            {
                for (int y = 0; y < currentFigure.GetLength(1); y++)
                {
                    if (currentFigure[x, y] == 1)
                    {
                        int fx = figureX + x;
                        int fy = figureY + y;

                        if (fx >= 0 && fx < FieldWidth && fy >= 0 && fy < FieldHeight)
                        {
                            field[fx, fy] = 1;
                        }
                    }
                }
            }
        }

        void ClearLines()
        {
            for (int y = FieldHeight - 1; y >= 0; y--)
            {
                bool fullLine = true;
                for (int x = 0; x < FieldWidth; x++)
                {
                    if (field[x, y] == 0)
                    {
                        fullLine = false;
                        break;
                    }
                }

                if (fullLine)
                {
                    score += 100;

                    for (int yy = y; yy > 0; yy--)
                        for (int x = 0; x < FieldWidth; x++)
                            field[x, yy] = field[x, yy - 1];

                    for (int x = 0; x < FieldWidth; x++)
                        field[x, 0] = 0;

                    y++; // пересканировать строку
                }
            }
        }
    }
}